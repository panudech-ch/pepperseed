<?php
    include('../../connect.php');
    include('query_statement.php');
?>
<?php
    updateOrderPaymentToNull();
?>
